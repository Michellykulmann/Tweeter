tweeter
=======

Projeto de aula das turmas BSI12 e TSI13

O projeto consiste de construir um "clone" da ferramenta de microblogs Twitter, fazendo as simplificações necessárias para viabilizar a conclusão do projeto ao longo do semestre de aula.
São usadas como ferramentas para o desenvolvimento do projeto:

- Codeigniter
- Bootstrap
- jQuery
- Font Awesome
